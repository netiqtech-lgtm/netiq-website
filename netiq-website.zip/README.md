# NetIQ Technologies Website

Official website for NetIQ Technologies MSP.

## Sections
- Hero (Intro)
- Services
- About
- Contact

## Deployment
Can be deployed to Netlify or GitHub Pages easily.
